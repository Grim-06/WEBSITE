<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Personal Profile</title>
    <link rel="stylesheet" href="Profile.css">
</head>

<body>

    <header>
        <h1>My Personal Profile</h1>
    </header>

    <main>
        <div class="profile">
            <img src="Profile.jpg" alt="Profile Picture" width="100" height="100">
            <div class="profile-info">
                <h2>Darren Demetry Ison Avila</h2>
                <ul>
                    <li>Location: Caloocan City, Philippines</li>
                    <li>Age: 22 years old</li>
					<li>Birthdate: March 21, 2001</li>
					<li>Gender: Male</li>
					<li>Religion: Born Again</li>
                </ul>
            </div>
        </div>
		
		
		<div class="social-media-button">
    <a href="https://www.facebook.com/therenavila/" target="_blank"class="social-media-container">My Facebook.</a>
</div>

		<div class="social-media-button">
    <a href="https://www.instagram.com/the_ren_avila/" target="_blank"class="social-media-container">My Instagram.</a>
</div>


    <br>
	<br>
	<br>
        <div class="first-box">
            <div class="box">Memorable achievements I made:</div>
			<ul>
                    <li>Graduated senior high-school as the top student in my class.</li>
                    <li>Was elected as Student Council President in Junior High.</li>
					<li>Won a talent competition as champion in an event in National University.</li>
					<li>Represented my high-school campus in an inter-school spelling competition.<li>
                </ul>
        </div>
		
		<div class="second-box">
		<div class="box">Things I'm highly knowledgable about:</div>
		<ul>
                    <li>Leading a group.</li>
                    <li>Hardware side of gadgets like computers and phones.</li>
					<li>Vehicle trouble shootings.</li>
					<li>Cooking and Baking.</li>
					<li>Electrical systems and wiring.</li>
					<li>Music.</li>
                </ul>
		</div>
    </main>

    <footer>
        &copy; 2024 My Website. All rights reserved.
    </footer>

</body>

</html>
