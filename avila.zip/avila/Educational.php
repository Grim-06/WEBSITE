<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Educational Background</title>
    <link rel="stylesheet" href="EdBack.css">
</head>

<body>
		
    <header>
        <h1>My Educational Background</h1>
    </header>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
    <main class="gallery">
        <!-- Gallery Photos -->
        <div class="photo-box">
            <img src="Dominic.jpg" alt="Photo 1">
			<h2>Saint Dominic Academy.</h2>
            <p>Elementary.</p>
        </div>

        <div class="photo-box">
            <img src="Imma.jpg" alt="Photo 2">
			<br>
			<br>
			<br>
			<br>
			<h2>Immaculate Mother Academy.</h2>
            <p>Junior & Senior HighSchool.</p>
        </div>

        <div class="photo-box">
            <img src="Enyu.jpg" alt="Photo 3">
			<h2>National University.</h2>
            <p>College.</p>
        </div>
    </main>

    <footer>
        &copy; 2024 My Website. All rights reserved.
    </footer>

</body>

</html>
