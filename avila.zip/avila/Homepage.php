<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="HomeDes.css">
    <title>Welcome to my website!</title>
</head>
<body>
    <header>
		 <img src="your-logo.jpg" alt="Your Logo" class="logo">
		<p>Welcome to my website!</p>
        <h1>Hi! I'm Darren Demetry I. Avila.</h1>
		<h3>I'm a student at National University, <br> Studying Bachelor of Science in Information Technology specializing in Mobile Internet.</h3>
		
		
    </header>
	
		<h2>Know me more!</h2>
     <nav>
        <a href="profile.php">My Personal Profile</a>
        <a href="Interests.php">Interests</a>
		<a href="educational.php">Education Background</a>
    </nav>
        <h4><a href="Contact.php">Submit your feedbacks here!</a></h4>
    
</body>
</html>
