<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Feed.css">
    <style>
        /* Add styles for the contact form */
        .contact-form {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 9999; /* Ensure the form appears on top of other elements */
            background-color: #808080;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            max-width: 800px; /* Adjust the width as needed */
            width: 90%; /* Adjust the width as needed */
        }

        .contact-form h2 {
            margin-bottom: 20px;
            font-size: 36px;
            color: #FFFFFF;
        }

        .contact-form label {
            font-size: 20px;
            color: #FFFFFF;
        }

        .contact-form input[type="email"],
        .contact-form input[type="text"],
        .contact-form textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 18px;
        }

        .contact-form textarea {
            height: 150px;
        }

        .contact-form input[type="submit"] {
            background-color: #808080;
            color: #fff;
            border: none;
            padding: 15px 30px;
            cursor: pointer;
            font-size: 20px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .contact-form input[type="submit"]:hover {
            background-color: #000000;
        }
    </style>
    <title>Contact Us</title>
</head>
<body>
    <!-- Contact Form -->
    <div class="contact-form">
        <h2>Send your Feedbacks:</h2>
        <?php
            require_once "database.php";

            if (isset($_POST["submit"])) {
                $name = $_POST["name"];
                $email = $_POST["email"];
                $message = $_POST["message"];

                $errors = array();

                if (empty($name) || empty($email) || empty($message)) {
                    array_push($errors, "All fields are required");
                }
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    array_push($errors, "Email is not valid");
                }

                if (count($errors) > 0) {
                    foreach ($errors as $error) {
                        echo "<div class='alert alert-danger'>$error</div>";
                    }
                } else {
                    $sqlInsertInfo = "INSERT INTO contact_details_db (name, email, message) VALUES (?, ?, ?)";
                    $stmtInsertInfo = mysqli_stmt_init($conn);

                    if (mysqli_stmt_prepare($stmtInsertInfo, $sqlInsertInfo)) {
                        mysqli_stmt_bind_param($stmtInsertInfo, "sss", $name, $email, $message);
                        mysqli_stmt_execute($stmtInsertInfo);
                        echo "<div class='alert alert-success success-alert w-50 mx-auto text-center'>Your message has been submitted successfully.</div>";

                        // Get the AccountID of the inserted user
                        $accountID = mysqli_insert_id($conn);
                    } else {
                        die("Error in preparing SQL statement to insert user account");
                    }
                }
            }
        ?>
    <form method="post" action="Contact.php">
        <label for="name">Name:</label><br>
        <input type="text" id="name" name="name" required><br>
        
        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email" required><br>
        
        <label for="message">Message:</label><br>
        <textarea id="message" name="message" rows="4" required></textarea><br>
        
        <input type="submit" value="Submit" name="submit">
    </form>
    </div>
</body>
</html>
